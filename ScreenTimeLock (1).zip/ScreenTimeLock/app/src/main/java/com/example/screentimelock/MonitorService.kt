package com.example.screentimelock

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastTickEl = 0L
    private var lastQuery = 0L
    private var currentFg: String? = null
    private var sys: Map<String, Long> = emptyMap()
    private var lastSysRefresh = -100_000L
    private var exempt: Set<String> = emptySet()
    private var overlay: View? = null
    private var suppressUntil = 0L

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) { }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("guard", "Protection", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, "guard")
            .setSmallIcon(R.drawable.ic_lock)
            .setContentTitle("Screen time protection is on")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        try {
            ServiceCompat.startForeground(
                this, 1, n,
                if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
            )
            Status.err(this, "service", null)
        } catch (e: Exception) {
            Status.err(this, "service", e.toString())
        }
        exempt = Exempt.set(this)
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null

    override fun onTaskRemoved(rootIntent: Intent?) {
        try {
            androidx.core.content.ContextCompat.startForegroundService(
                this, Intent(this, MonitorService::class.java)
            )
        } catch (_: Exception) { }
        super.onTaskRemoved(rootIntent)
    }

    override fun onDestroy() {
        handler.removeCallbacks(loop)
        hideOverlay()
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun updateForeground() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        if (lastQuery > now) lastQuery = 0L
        val begin = if (lastQuery == 0L) now - 24 * 3600_000L else lastQuery - 2000
        val events = usm.queryEvents(begin, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> currentFg = e.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (currentFg == e.packageName) currentFg = null
            }
        }
        lastQuery = now
    }

    private fun tick() {
        val el = SystemClock.elapsedRealtime()
        val delta = if (lastTickEl == 0L) 0L else minOf(el - lastTickEl, 5000L)
        lastTickEl = el
        Status.beat(this)

        val day = TimeGuard.today(this)
        LimitStore.rollover(this, day)
        if (!SystemUsage.hasAccess(this)) { hideOverlay(); return }

        updateForeground()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val active = pm.isInteractive && !km.isKeyguardLocked
        val fg = if (active) currentFg else null
        Status.setFg(this, fg ?: "-")

        if (el - lastSysRefresh > 15_000) {
            sys = SystemUsage.todayMap(this)
            exempt = Exempt.set(this)
            lastSysRefresh = el
        }

        var blocked = false
        if (fg != null && fg !in exempt) {
            val reason = Policy.reason(this, day, fg, sys, exempt)
            if (reason != Reason.NONE) {
                blocked = true
                if (el > suppressUntil && Settings.canDrawOverlays(this)) showOverlay(fg, reason)
            } else {
                UsageStore.add(this, day, fg, delta)
            }
        }
        if (!blocked) hideOverlay()
    }

    // ---------- Lock screen drawn as a real overlay window ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun goHome() {
        hideOverlay()
        suppressUntil = SystemClock.elapsedRealtime() + 2500
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    private fun showOverlay(pkg: String, reason: Reason) {
        if (overlay != null) return
        val name = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }

        val root = object : LinearLayout(this) {
            override fun dispatchKeyEvent(event: KeyEvent): Boolean {
                if (event.keyCode == KeyEvent.KEYCODE_BACK) {
                    if (event.action == KeyEvent.ACTION_UP) goHome()
                    return true
                }
                return super.dispatchKeyEvent(event)
            }
        }
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER
        root.setPadding(dp(32), dp(48), dp(32), dp(32))
        root.setBackgroundResource(R.drawable.bg_block)
        root.isFocusable = true
        root.isFocusableInTouchMode = true
        root.isClickable = true

        val circle = FrameLayout(this)
        circle.setBackgroundResource(R.drawable.bg_circle)
        val lock = ImageView(this)
        lock.setImageResource(R.drawable.ic_lock)
        circle.addView(lock, FrameLayout.LayoutParams(dp(56), dp(56), Gravity.CENTER))
        root.addView(circle, LinearLayout.LayoutParams(dp(112), dp(112)))

        fun text(t: String, size: Float, alpha: Float, bold: Boolean, top: Int): TextView =
            TextView(this).apply {
                this.text = t
                textSize = size
                this.alpha = alpha
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
                root.addView(this, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { topMargin = dp(top) })
            }

        text(if (reason == Reason.TOTAL) "Daily screen time is over" else "Time's up for $name", 28f, 1f, true, 28)
        text("You've used today's limit.\nRaising the limit won't unlock it today. New limits start tomorrow.", 16f, 0.75f, false, 12)

        val btn = Button(this).apply {
            text = "Go to Home"
            isAllCaps = false
            setTextColor(Color.parseColor("#312E81"))
            textSize = 16f
            background = GradientDrawable().apply {
                setColor(Color.WHITE)
                cornerRadius = dp(28).toFloat()
            }
            setOnClickListener { goHome() }
        }
        root.addView(btn, LinearLayout.LayoutParams(dp(220), dp(56)).apply { topMargin = dp(36) })
        text("Your limits reset at midnight", 13f, 0.5f, false, 20)

        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.OPAQUE
        )
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode =
                WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            (getSystemService(Context.WINDOW_SERVICE) as WindowManager).addView(root, lp)
            overlay = root
            root.post { root.requestFocus() }
            Status.err(this, "overlay", null)
        } catch (e: Exception) {
            overlay = null
            Status.err(this, "overlay", e.toString())
        }
    }

    private fun hideOverlay() {
        overlay?.let {
            try { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (_: Exception) { }
        }
        overlay = null
    }
}
