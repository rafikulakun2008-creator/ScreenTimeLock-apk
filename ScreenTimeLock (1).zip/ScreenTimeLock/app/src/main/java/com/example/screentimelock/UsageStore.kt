package com.example.screentimelock

import android.app.AppOpsManager
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Process
import android.os.SystemClock
import java.time.LocalDate
import java.time.ZoneId

/** Own per-day usage counters (milliseconds), keyed by trusted day number. */
object UsageStore {
    private const val ALL = "__all__"
    private fun sp(c: Context) = c.getSharedPreferences("usage", Context.MODE_PRIVATE)

    fun get(c: Context, day: Long, pkg: String) = sp(c).getLong("u_${day}_$pkg", 0L)
    fun all(c: Context, day: Long) = get(c, day, ALL)

    fun add(c: Context, day: Long, pkg: String, ms: Long) {
        if (ms <= 0) return
        val p = sp(c)
        val k = "u_${day}_$pkg"
        val ka = "u_${day}_$ALL"
        p.edit().putLong(k, p.getLong(k, 0L) + ms).putLong(ka, p.getLong(ka, 0L) + ms).apply()
    }

    fun cleanup(c: Context, day: Long) {
        val p = sp(c)
        if (p.getLong("clean_day", -1L) == day) return
        val ed = p.edit()
        p.all.keys.filter { it.startsWith("u_") && !it.startsWith("u_${day}_") }.forEach { ed.remove(it) }
        ed.putLong("clean_day", day).apply()
    }
}

/** Service heartbeat + last errors, so the main screen can show whether protection is really running. */
object Status {
    private fun sp(c: Context) = c.getSharedPreferences("status", Context.MODE_PRIVATE)
    fun beat(c: Context) { sp(c).edit().putLong("hb", SystemClock.elapsedRealtime()).apply() }
    fun setFg(c: Context, fg: String) { sp(c).edit().putString("fg", fg).apply() }
    fun fg(c: Context): String? = sp(c).getString("fg", null)
    fun err(c: Context, k: String, msg: String?) {
        val ed = sp(c).edit()
        if (msg == null) ed.remove("err_$k") else ed.putString("err_$k", msg.take(120))
        ed.apply()
    }
    fun err(c: Context, k: String): String? = sp(c).getString("err_$k", null)
    fun running(c: Context): Boolean {
        val d = SystemClock.elapsedRealtime() - sp(c).getLong("hb", -100_000L)
        return d in 0..5000
    }
}

/** Android's usage data, computed from raw events so the numbers are exact for today. */
object SystemUsage {
    fun hasAccess(c: Context): Boolean {
        val ops = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= 29)
            ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        else
            @Suppress("DEPRECATION")
            ops.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), c.packageName)
        return if (mode == AppOpsManager.MODE_DEFAULT)
            c.checkCallingOrSelfPermission(android.Manifest.permission.PACKAGE_USAGE_STATS) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        else mode == AppOpsManager.MODE_ALLOWED
    }

    /** package -> foreground milliseconds since local midnight. */
    @Suppress("DEPRECATION")
    fun todayMap(c: Context): Map<String, Long> {
        if (!hasAccess(c)) return emptyMap()
        val usm = c.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant().toEpochMilli()
        val events = usm.queryEvents(start, now)
        val e = UsageEvents.Event()
        val total = HashMap<String, Long>()
        var cur: String? = null
        var curStart = 0L
        fun end(t: Long) {
            cur?.let { total[it] = (total[it] ?: 0L) + maxOf(0L, t - curStart) }
            cur = null
        }
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            val pkg = e.packageName ?: continue
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> if (cur != pkg) {
                    end(e.timeStamp); cur = pkg; curStart = e.timeStamp
                }
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (cur == pkg) end(e.timeStamp)
                16, 17, 26 -> end(e.timeStamp) // screen off, keyguard shown, shutdown
            }
        }
        if (cur != null) end(now)
        return total
    }
}

/** Apps that are never blocked: this app, launcher, system UI, phone/dialer. */
object Exempt {
    fun set(c: Context): Set<String> {
        val pm = c.packageManager
        val s = mutableSetOf(
            c.packageName, "com.android.systemui", "com.android.phone", "com.android.incallui",
            "com.android.server.telecom", "com.android.emergency"
        )
        pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
            .forEach { s.add(it.activityInfo.packageName) }
        pm.queryIntentActivities(Intent(Intent.ACTION_DIAL), 0)
            .forEach { s.add(it.activityInfo.packageName) }
        return s
    }
}

enum class Reason { NONE, APP, TOTAL }

object Policy {
    fun usageMs(c: Context, day: Long, pkg: String, sys: Map<String, Long>) =
        maxOf(UsageStore.get(c, day, pkg), sys[pkg] ?: 0L)

    fun totalMs(c: Context, day: Long, sys: Map<String, Long>, exempt: Set<String>) =
        maxOf(UsageStore.all(c, day), sys.filterKeys { it !in exempt }.values.sum())

    fun reason(c: Context, day: Long, pkg: String, sys: Map<String, Long>, exempt: Set<String>): Reason {
        LimitStore.current(c, LimitStore.TOTAL)?.let {
            if (totalMs(c, day, sys, exempt) >= it * 60_000L) return Reason.TOTAL
        }
        LimitStore.current(c, pkg)?.let {
            if (usageMs(c, day, pkg, sys) >= it * 60_000L) return Reason.APP
        }
        return Reason.NONE
    }
}
