package com.example.screentimelock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.widget.doAfterTextChanged
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.screentimelock.databinding.ActivityMainBinding
import com.example.screentimelock.databinding.DialogLimitBinding
import com.example.screentimelock.databinding.ItemAppBinding
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.snackbar.Snackbar

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val adapter = AppAdapter()
    private var apps: List<Triple<String, String, Drawable>> = emptyList() // pkg, label, icon
    private var allRows: List<Row> = emptyList()
    private var totalLocked = false

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    private val refresher = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 10_000) }
    }

    data class Row(
        val pkg: String, val label: String, val icon: Drawable,
        val usageMs: Long, val limit: Int?, val pending: Int?
    ) {
        val locked get() = limit != null && usageMs >= limit * 60_000L
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.btnPerm.setOnClickListener { fixNextPermission() }
        b.btnHelp.setOnClickListener { showRestrictedHelp() }
        b.btnTotal.setOnClickListener {
            showLimitDialog(LimitStore.TOTAL, "Total daily screen time", totalLocked)
        }
        b.searchInput.doAfterTextChanged { render() }
        b.filterGroup.setOnCheckedStateChangeListener { _, _ -> render() }
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .map { (pkg, ri) -> Triple(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)) }
    }

    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasBattery() =
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun fixNextPermission() {
        when {
            !SystemUsage.hasAccess(this) -> try {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS, Uri.parse("package:$packageName")))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            }
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            !hasNotif() -> notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            !hasBattery() -> startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun updateStatus(usage: Boolean, overlay: Boolean) {
        val running = Status.running(this)
        val sb = StringBuilder()
        sb.append(if (running) "Protection: running ✓" else "Protection: NOT running ✗")
        if (running) Status.fg(this)?.let { sb.append("   (app in front: $it)") }
        if (!usage) sb.append("\nUsage access is missing, so limits cannot work.")
        if (!overlay) sb.append("\nDisplay over other apps is missing, so the lock screen cannot show.")
        Status.err(this, "service")?.let { sb.append("\nService error: $it") }
        Status.err(this, "overlay")?.let { sb.append("\nLock screen error: $it") }
        if (!running && usage) {
            sb.append("\nTip: set Battery to \"No restrictions\", turn on Autostart, and lock this app in Recents.")
        }
        b.statusLine.text = sb.toString()
        b.statusLine.setTextColor(if (running && usage && overlay) 0xFF16A34A.toInt() else 0xFFDC2626.toInt())
    }

    private fun showRestrictedHelp() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Can't turn on a permission?")
            .setMessage(
                "On Android 13 and newer, apps installed from an APK file are restricted until you allow them:\n\n" +
                    "1. Tap \"Open App info\".\n" +
                    "2. Tap the ⋮ menu (top right).\n" +
                    "3. Tap \"Allow restricted settings\".\n" +
                    "4. Come back here and turn on Usage access and Display over other apps.\n\n" +
                    "If you don't see the ⋮ menu, first try turning the permission on once (it will be blocked), then repeat these steps."
            )
            .setPositiveButton("Open App info") { _, _ ->
                startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
                )
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun statusColor(f: Float): Int = when {
        f >= 1f -> 0xFFEF4444.toInt()
        f >= 0.8f -> 0xFFF59E0B.toInt()
        else -> 0xFF22C55E.toInt()
    }

    private fun refresh() {
        val day = TimeGuard.today(this)
        LimitStore.rollover(this, day)

        val usage = SystemUsage.hasAccess(this)
        val overlay = Settings.canDrawOverlays(this)
        val notif = hasNotif()
        val battery = hasBattery()
        fun line(ok: Boolean, t: String) = (if (ok) "✓  " else "○  ") + t
        b.permList.text = listOf(
            line(usage, "Usage access: see which app is open"),
            line(overlay, "Display over other apps: show the lock screen"),
            line(notif, "Notifications: keep protection running"),
            line(battery, "Unrestricted battery: stop Android pausing the app")
        ).joinToString("\n")
        b.permCard.visibility = if (usage && overlay && notif && battery) View.GONE else View.VISIBLE
        if (usage) {
            try {
                ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))
            } catch (e: Exception) {
                Status.err(this, "service", e.toString())
            }
        }
        updateStatus(usage, overlay)
        handler.postDelayed({ updateStatus(usage, overlay) }, 2000)

        val sys = SystemUsage.todayMap(this)
        val exempt = Exempt.set(this)
        allRows = apps.map { (pkg, label, icon) ->
            Row(
                pkg, label, icon,
                Policy.usageMs(this, day, pkg, sys),
                LimitStore.current(this, pkg),
                LimitStore.pending(this, pkg)
            )
        }.sortedWith(
            compareByDescending<Row> { it.limit != null }
                .thenByDescending { it.usageMs }
                .thenBy { it.label.lowercase() }
        )

        // Total card
        val totalLimit = LimitStore.current(this, LimitStore.TOTAL)
        val totalPending = LimitStore.pending(this, LimitStore.TOTAL)
        val used = Policy.totalMs(this, day, sys, exempt)
        b.totalBig.text = fmtMs(used)
        totalLocked = totalLimit != null && used >= totalLimit * 60_000L
        if (totalLimit != null) {
            val frac = (used.toFloat() / (totalLimit * 60_000f)).coerceIn(0f, 1f)
            b.ringBox.visibility = View.VISIBLE
            b.totalRing.setProgressCompat((frac * 100).toInt(), false)
            b.totalRing.setIndicatorColor(statusColor(frac))
            b.totalPercent.text = "${(frac * 100).toInt()}%"
            b.totalSub.text = if (totalLocked) "Locked for today" else "of ${fmtMin(totalLimit)} daily limit"
            b.btnTotal.text = "Change total limit"
        } else {
            b.ringBox.visibility = View.GONE
            b.totalSub.text = "No total limit set"
            b.btnTotal.text = "Set total limit"
        }
        if (totalPending != null) {
            b.totalPending.visibility = View.VISIBLE
            b.totalPending.text = "From tomorrow: " + (if (totalPending == 0) "no limit" else fmtMin(totalPending))
        } else b.totalPending.visibility = View.GONE

        render()
    }

    private fun render() {
        val q = b.searchInput.text.toString().trim().lowercase()
        val limitedOnly = b.chipLimited.isChecked
        val list = allRows.filter { (!limitedOnly || it.limit != null) && it.label.lowercase().contains(q) }
        adapter.submit(list)
        b.emptyText.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun fmtMin(m: Int) = when {
        m < 60 -> "${m}m"
        m % 60 == 0 -> "${m / 60}h"
        else -> "${m / 60}h ${m % 60}m"
    }

    private fun fmtMs(ms: Long) = if (ms in 1..59_999) "<1m" else fmtMin((ms / 60_000L).toInt())

    private fun showLimitDialog(key: String, title: String, locked: Boolean) {
        val day = TimeGuard.today(this)
        val cur = LimitStore.current(this, key)
        val d = DialogLimitBinding.inflate(layoutInflater)
        d.dlgInfo.text = "Lowering a limit applies right away. Raising or removing it only starts tomorrow."
        if (locked) {
            d.dlgWarn.visibility = View.VISIBLE
            d.dlgWarn.text = "Already used up today. A new limit won't unlock it until tomorrow."
        }
        cur?.let {
            d.dlgHours.setText((it / 60).toString())
            d.dlgMinutes.setText((it % 60).toString())
        }
        listOf(15 to "15 min", 30 to "30 min", 60 to "1 h", 120 to "2 h", 180 to "3 h", 240 to "4 h")
            .forEach { (min, label) ->
                d.quickChips.addView(Chip(this).apply {
                    text = label
                    setOnClickListener {
                        d.dlgHours.setText((min / 60).toString())
                        d.dlgMinutes.setText((min % 60).toString())
                    }
                })
            }

        val dlg = MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setView(d.root)
            .setPositiveButton("Set limit") { _, _ ->
                val total = (d.dlgHours.text.toString().toIntOrNull() ?: 0) * 60 +
                    (d.dlgMinutes.text.toString().toIntOrNull() ?: 0)
                if (total <= 0) {
                    Snackbar.make(b.root, "Enter a time greater than zero", Snackbar.LENGTH_SHORT).show()
                } else {
                    showResult(LimitStore.set(this, key, total, day))
                    refresh()
                }
            }
            .setNegativeButton("Cancel", null)
        if (cur != null) {
            dlg.setNeutralButton("Remove limit") { _, _ ->
                showResult(LimitStore.remove(this, key, day))
                refresh()
            }
        }
        dlg.show()
    }

    private fun showResult(r: LimitStore.Result) {
        val msg = if (r == LimitStore.Result.APPLIED_NOW) "Limit is active now"
        else "New limit starts tomorrow"
        Snackbar.make(b.root, msg, Snackbar.LENGTH_LONG).show()
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var rows: List<Row> = emptyList()
        fun submit(r: List<Row>) { rows = r; notifyDataSetChanged() }

        inner class VH(val v: ItemAppBinding) : RecyclerView.ViewHolder(v.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val r = rows[position]
            val v = h.v
            v.icon.setImageDrawable(r.icon)
            v.name.text = r.label
            v.status.text = "Used today: ${fmtMs(r.usageMs)}"

            val notes = mutableListOf<String>()
            if (r.limit != null) {
                val frac = (r.usageMs.toFloat() / (r.limit * 60_000f)).coerceIn(0f, 1f)
                v.limitLabel.text = fmtMin(r.limit)
                v.limitLabel.alpha = 1f
                v.progress.visibility = View.VISIBLE
                v.progress.setProgressCompat((frac * 100).toInt(), false)
                v.progress.setIndicatorColor(statusColor(frac))
                if (r.locked) notes.add("Locked until tomorrow")
            } else {
                v.limitLabel.text = "No limit"
                v.limitLabel.alpha = 0.5f
                v.progress.visibility = View.GONE
            }
            r.pending?.let {
                notes.add("From tomorrow: " + (if (it == 0) "no limit" else fmtMin(it)))
            }
            if (notes.isEmpty()) v.note.visibility = View.GONE else {
                v.note.visibility = View.VISIBLE
                v.note.text = notes.joinToString("\n")
                v.note.setTextColor(if (r.locked) 0xFFEF4444.toInt() else v.status.currentTextColor)
            }
            v.root.setOnClickListener { showLimitDialog(r.pkg, r.label, r.locked) }
        }
    }
}
