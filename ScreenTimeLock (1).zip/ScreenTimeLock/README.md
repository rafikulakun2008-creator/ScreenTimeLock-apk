# Screen Time Lock (Android)

Daily app limits that can't be cheated: once an app's limit is used up, raising the limit
only takes effect from the next day. Lowering a limit applies immediately.

Build the APK:
1. GitHub Actions (see .github/workflows/build.yml), or
2. Android Studio: Open this folder -> Build > Build APK(s).
