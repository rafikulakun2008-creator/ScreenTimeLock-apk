# স্ক্রিন টাইম লক (Android)

APK বানানোর দুটি উপায়:
1. GitHub-এ আপলোড করলে .github/workflows/build.yml নিজে থেকে APK বানাবে (Actions > Artifacts থেকে নামান)।
2. Android Studio-তে Open -> Build > Build APK(s)।

APK ফোনে নিয়ে ইনস্টল করুন (Unknown sources অনুমতি দিতে হবে)।
