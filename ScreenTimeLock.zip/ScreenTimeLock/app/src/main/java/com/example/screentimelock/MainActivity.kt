package com.example.screentimelock

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.screentimelock.databinding.ActivityMainBinding
import com.example.screentimelock.databinding.ItemAppBinding

class MainActivity : AppCompatActivity() {
    private lateinit var b: ActivityMainBinding
    private val handler = Handler(Looper.getMainLooper())
    private val adapter = AppAdapter()
    private var apps: List<Triple<String, String, Drawable>> = emptyList() // pkg, label, icon

    private val notifPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { refresh() }

    private val refresher = object : Runnable {
        override fun run() { refresh(); handler.postDelayed(this, 10_000) }
    }

    data class Row(val pkg: String, val label: String, val icon: Drawable, val usageMs: Long, val limit: Int?, val pending: Int?)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.list.layoutManager = LinearLayoutManager(this)
        b.list.adapter = adapter
        b.btnPerm.setOnClickListener { fixNextPermission() }
        b.btnTotal.setOnClickListener { showLimitDialog(LimitStore.TOTAL, "মোট স্ক্রিন টাইম (সব অ্যাপ মিলিয়ে)") }
        loadApps()
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        handler.removeCallbacks(refresher)
        super.onPause()
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        apps = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .map { (pkg, ri) -> Triple(pkg, ri.loadLabel(pm).toString(), ri.loadIcon(pm)) }
    }

    private fun hasNotif() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun hasBattery() =
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)

    private fun fixNextPermission() {
        when {
            !SystemUsage.hasAccess(this) -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            !Settings.canDrawOverlays(this) -> startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            !hasNotif() -> notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
            !hasBattery() -> startActivity(
                Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
            )
        }
    }

    private fun refresh() {
        val day = TimeGuard.today(this)
        LimitStore.rollover(this, day)

        val usage = SystemUsage.hasAccess(this)
        val overlay = Settings.canDrawOverlays(this)
        val notif = hasNotif()
        val battery = hasBattery()
        val coreOk = usage && overlay
        b.permStatus.text = "Usage Access: ${if (usage) "✅" else "❌"}   " +
            "Overlay: ${if (overlay) "✅" else "❌"}   " +
            "Notification: ${if (notif) "✅" else "❌"}   " +
            "Battery: ${if (battery) "✅" else "⚠️"}"
        val allOk = coreOk && notif && battery
        b.btnPerm.visibility = if (allOk) android.view.View.GONE else android.view.View.VISIBLE
        b.btnPerm.text = "পারমিশন ঠিক করুন"
        if (coreOk) ContextCompat.startForegroundService(this, Intent(this, MonitorService::class.java))

        val sys = SystemUsage.todayMap(this)
        val exempt = Exempt.set(this)
        val rows = apps.map { (pkg, label, icon) ->
            Row(
                pkg, label, icon,
                Policy.usageMs(this, day, pkg, sys),
                LimitStore.current(this, pkg),
                LimitStore.pending(this, pkg)
            )
        }.sortedWith(compareByDescending<Row> { it.limit != null }.thenByDescending { it.usageMs }.thenBy { it.label.lowercase() })
        adapter.submit(rows)

        val totalLimit = LimitStore.current(this, LimitStore.TOTAL)
        val totalPending = LimitStore.pending(this, LimitStore.TOTAL)
        val totalUsed = Policy.totalMs(this, day, sys, exempt)
        b.totalInfo.text = "মোট আজ: ${fmtMs(totalUsed)} / " +
            (totalLimit?.let { fmtMin(it) } ?: "সীমা নেই") +
            pendingText(totalPending)
    }

    private fun fmtMin(m: Int) = if (m < 60) "$m মি" else if (m % 60 == 0) "${m / 60} ঘ" else "${m / 60} ঘ ${m % 60} মি"
    private fun fmtMs(ms: Long) = fmtMin((ms / 60_000L).toInt())
    private fun pendingText(p: Int?) = when {
        p == null -> ""
        p == 0 -> "\nআগামীকাল থেকে: সীমা থাকবে না"
        else -> "\nআগামীকাল থেকে: ${fmtMin(p)}"
    }

    private fun showLimitDialog(key: String, title: String) {
        val day = TimeGuard.today(this)
        val cur = LimitStore.current(this, key)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(pad, pad, pad, 0) }
        fun field(hint: String, init: Int?) = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            this.hint = hint
            init?.let { setText(it.toString()) }
            layout.addView(this, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val h = field("ঘণ্টা", cur?.div(60))
        val m = field("মিনিট", cur?.rem(60))

        val dlg = AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage("সীমা কমালে এখনই কার্যকর হবে। সীমা বাড়ালে বা সরালে আগামীকাল থেকে কার্যকর হবে।")
            .setView(layout)
            .setPositiveButton("সেট করুন") { _, _ ->
                val total = (h.text.toString().toIntOrNull() ?: 0) * 60 + (m.text.toString().toIntOrNull() ?: 0)
                if (total <= 0) {
                    Toast.makeText(this, "সময় দিন", Toast.LENGTH_SHORT).show()
                } else {
                    val r = LimitStore.set(this, key, total, day)
                    toastResult(r)
                    refresh()
                }
            }
            .setNegativeButton("বাতিল", null)
        if (cur != null) {
            dlg.setNeutralButton("সীমা সরান") { _, _ ->
                toastResult(LimitStore.remove(this, key, day))
                refresh()
            }
        }
        dlg.show()
    }

    private fun toastResult(r: LimitStore.Result) {
        val msg = if (r == LimitStore.Result.APPLIED_NOW) "সীমা এখনই কার্যকর হয়েছে"
        else "নতুন সীমা আগামীকাল থেকে কার্যকর হবে"
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    inner class AppAdapter : RecyclerView.Adapter<AppAdapter.VH>() {
        private var rows: List<Row> = emptyList()
        fun submit(r: List<Row>) { rows = r; notifyDataSetChanged() }

        inner class VH(val v: ItemAppBinding) : RecyclerView.ViewHolder(v.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
            VH(ItemAppBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun getItemCount() = rows.size

        override fun onBindViewHolder(h: VH, position: Int) {
            val r = rows[position]
            h.v.icon.setImageDrawable(r.icon)
            h.v.name.text = r.label
            val blocked = r.limit != null && r.usageMs >= r.limit * 60_000L
            h.v.status.text = "আজ: ${fmtMs(r.usageMs)}  |  " +
                (r.limit?.let { "সীমা: ${fmtMin(it)}" } ?: "সীমা নেই") +
                (if (blocked) "  🔒 আজ বন্ধ" else "") +
                pendingText(r.pending)
            h.v.root.setOnClickListener { showLimitDialog(r.pkg, r.label) }
        }
    }
}
