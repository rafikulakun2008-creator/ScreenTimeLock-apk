package com.example.screentimelock

import android.content.Context
import android.os.SystemClock
import java.time.Instant
import java.time.ZoneId

/**
 * Tamper-resistant clock. Within one boot, time is derived from elapsedRealtime so changing the
 * phone's date/time has no effect. After a reboot, time can never go backwards.
 */
object TimeGuard {
    private fun sp(c: Context) = c.getSharedPreferences("timeguard", Context.MODE_PRIVATE)

    @Synchronized
    fun now(c: Context): Long {
        val p = sp(c)
        val wall = System.currentTimeMillis()
        val el = SystemClock.elapsedRealtime()
        val lastEl = p.getLong("last_el", -1L)
        var base = p.getLong("base", Long.MIN_VALUE)
        if (base == Long.MIN_VALUE || el < lastEl) { // first run or after reboot
            base = wall - el
            val lastTrusted = p.getLong("last_trusted", Long.MIN_VALUE)
            if (lastTrusted != Long.MIN_VALUE) base = maxOf(base, lastTrusted - el)
        }
        val trusted = base + el
        p.edit().putLong("base", base).putLong("last_el", el).putLong("last_trusted", trusted).apply()
        return trusted
    }

    /** Current day number (epoch day). Never goes backwards. */
    @Synchronized
    fun today(c: Context): Long {
        val computed = Instant.ofEpochMilli(now(c)).atZone(ZoneId.systemDefault()).toLocalDate().toEpochDay()
        val p = sp(c)
        val last = p.getLong("last_day", 0L)
        val day = maxOf(computed, last)
        if (day != last) p.edit().putLong("last_day", day).apply()
        return day
    }
}
