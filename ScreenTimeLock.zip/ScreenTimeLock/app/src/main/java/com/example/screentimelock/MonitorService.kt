package com.example.screentimelock

import android.app.KeyguardManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.provider.Settings
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

class MonitorService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var lastTickEl = 0L
    private var lastQuery = 0L
    private var currentFg: String? = null
    private var sys: Map<String, Long> = emptyMap()
    private var lastSysRefresh = -100_000L
    private var lastBlockLaunch = 0L
    private var exempt: Set<String> = emptySet()

    private val loop = object : Runnable {
        override fun run() {
            try { tick() } catch (_: Exception) { }
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("guard", "স্ক্রিন টাইম সুরক্ষা", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n: Notification = NotificationCompat.Builder(this, "guard")
            .setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("স্ক্রিন টাইম সুরক্ষা চালু আছে")
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        ServiceCompat.startForeground(
            this, 1, n,
            if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        )
        exempt = Exempt.set(this)
        handler.post(loop)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int) = START_STICKY
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        handler.removeCallbacks(loop)
        super.onDestroy()
    }

    @Suppress("DEPRECATION")
    private fun updateForeground() {
        val usm = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val now = System.currentTimeMillis()
        if (lastQuery > now) lastQuery = 0L
        val begin = if (lastQuery == 0L) now - 24 * 3600_000L else lastQuery - 2000
        val events = usm.queryEvents(begin, now)
        val e = UsageEvents.Event()
        while (events.hasNextEvent()) {
            events.getNextEvent(e)
            when (e.eventType) {
                UsageEvents.Event.MOVE_TO_FOREGROUND -> currentFg = e.packageName
                UsageEvents.Event.MOVE_TO_BACKGROUND -> if (currentFg == e.packageName) currentFg = null
            }
        }
        lastQuery = now
    }

    private fun tick() {
        val el = SystemClock.elapsedRealtime()
        val delta = if (lastTickEl == 0L) 0L else minOf(el - lastTickEl, 5000L)
        lastTickEl = el

        val day = TimeGuard.today(this)
        LimitStore.rollover(this, day)
        if (!SystemUsage.hasAccess(this)) return

        updateForeground()
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        val active = pm.isInteractive && !km.isKeyguardLocked
        val fg = if (active) currentFg else null

        if (el - lastSysRefresh > 15_000) {
            sys = SystemUsage.todayMap(this)
            exempt = Exempt.set(this)
            lastSysRefresh = el
        }
        if (fg == null || fg in exempt) return

        UsageStore.add(this, day, fg, delta)
        val reason = Policy.reason(this, day, fg, sys, exempt)
        if (reason != Reason.NONE && el - lastBlockLaunch > 1500 && Settings.canDrawOverlays(this)) {
            lastBlockLaunch = el
            startActivity(
                Intent(this, BlockActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    .putExtra("pkg", fg)
                    .putExtra("reason", reason.name)
            )
        }
    }
}
