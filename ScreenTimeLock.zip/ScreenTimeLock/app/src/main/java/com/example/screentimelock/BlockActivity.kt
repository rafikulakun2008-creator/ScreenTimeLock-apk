package com.example.screentimelock

import android.content.Intent
import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.screentimelock.databinding.ActivityBlockBinding

class BlockActivity : AppCompatActivity() {
    private lateinit var b: ActivityBlockBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityBlockBinding.inflate(layoutInflater)
        setContentView(b.root)
        b.btnHome.setOnClickListener { goHome() }
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = goHome()
        })
        render(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        render(intent)
    }

    private fun render(i: Intent) {
        val pkg = i.getStringExtra("pkg") ?: ""
        val total = i.getStringExtra("reason") == Reason.TOTAL.name
        val name = try {
            packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Exception) { pkg }
        b.title.text = if (total) "আজকের মোট স্ক্রিন টাইম শেষ" else "$name — আজকের সময় শেষ"
        b.msg.text = "সীমা বাড়ালেও আজ আর এটা খুলবে না।\nনতুন সীমা আগামীকাল থেকে কার্যকর হবে।"
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }
}
