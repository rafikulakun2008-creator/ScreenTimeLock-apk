package com.example.screentimelock

import android.content.Context

/**
 * Limits in minutes. The key rule lives in [set] / [remove]:
 *  - lowering a limit applies immediately
 *  - raising or removing a limit only applies from the NEXT day
 */
object LimitStore {
    const val TOTAL = "__total__"

    enum class Result { APPLIED_NOW, SCHEDULED_TOMORROW }

    private fun sp(c: Context) = c.getSharedPreferences("limits", Context.MODE_PRIVATE)

    fun current(c: Context, key: String): Int? = sp(c).getInt("cur_$key", 0).takeIf { it > 0 }

    /** null = nothing pending, 0 = limit will be removed tomorrow, >0 = new limit tomorrow */
    fun pending(c: Context, key: String): Int? {
        val p = sp(c)
        return if (p.contains("pend_$key")) p.getInt("pend_$key", 0) else null
    }

    fun set(c: Context, key: String, minutes: Int, today: Long): Result {
        val p = sp(c)
        val cur = current(c, key)
        return if (cur == null || minutes <= cur) {
            p.edit().putInt("cur_$key", minutes).remove("pend_$key").remove("pendDate_$key").apply()
            Result.APPLIED_NOW
        } else {
            p.edit().putInt("pend_$key", minutes).putLong("pendDate_$key", today + 1).apply()
            Result.SCHEDULED_TOMORROW
        }
    }

    fun remove(c: Context, key: String, today: Long): Result {
        if (current(c, key) == null) return Result.APPLIED_NOW
        sp(c).edit().putInt("pend_$key", 0).putLong("pendDate_$key", today + 1).apply()
        return Result.SCHEDULED_TOMORROW
    }

    fun rollover(c: Context, today: Long) {
        val p = sp(c)
        val ed = p.edit()
        var changed = false
        for (k in p.all.keys.filter { it.startsWith("pend_") }) {
            val key = k.removePrefix("pend_")
            if (today >= p.getLong("pendDate_$key", 0L)) {
                val v = p.getInt(k, 0)
                if (v > 0) ed.putInt("cur_$key", v) else ed.remove("cur_$key")
                ed.remove(k).remove("pendDate_$key")
                changed = true
            }
        }
        if (changed) ed.apply()
        UsageStore.cleanup(c, today)
    }
}
